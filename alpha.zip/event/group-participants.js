import config from "../config.js"

export default async function GroupParticipants(hisoka, { id, participants, action }) {
   try {
      // participants
      for (const jid of participants) {
         // action
         if (action == "add") {
            if (!db.groups[id]?.welcome) return
            hisoka.sendMessage(id, {
               text: "Welcome! @"+jid.split("@")[0], mentions: [jid]
            }, { ephemeralExpiration: 86400 })
         } else if (action == "remove") {
            if (!db.groups[id]?.leave) return
            hisoka.sendMessage(id, {
               text: "Goodbye! @"+jid.split("@")[0], mentions: [jid]
            }, { ephemeralExpiration: 86400 })
         }
      }
   } catch (e) {
      throw e
   }
}