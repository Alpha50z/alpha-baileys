import config from "./config.js"
import { Client, Serialize } from "./lib/serialize.js"

import baileys from "@whiskeysockets/baileys"
const { useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidNormalizedUser, makeCacheableSignalKeyStore, PHONENUMBER_MCC } = baileys
import { Boom } from "@hapi/boom"
import Pino from "pino"
import NodeCache from "node-cache"
import readline from "readline"
import { parsePhoneNumber } from "libphonenumber-js"

const database = (new (await import("./lib/database.js")).default())
const store = makeInMemoryStore({
	logger: Pino({ level: "fatal" }).child({ level: "fatal" })
})

const pairingCode = process.argv.includes("--pairing-code")
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

// start connect to client
async function start() {
process.on("unhandledRejection", (err) => console.error(err))

const content = await database.read()
	if (content && Object.keys(content).length === 0) {
		global.db = {
			settings: {},
			users: {},
			groups: {},
			...(content || {}),
		}
		await database.write(global.db)
	} else {
		global.db = content
	}

   const { state, saveCreds } = await useMultiFileAuthState("./temp/auth")
   const msgRetryCounterCache = new NodeCache() // for retry message, "waiting message"

   const hisoka = baileys.default({
      logger: Pino({ level: "fatal" }).child({ level: "fatal" }), // hide log
      printQRInTerminal: !pairingCode, // popping up QR in terminal log
      auth: {
         creds: state.creds,
         keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "fatal" }).child({ level: "fatal" })),
      },
      browser: ['Chrome (Linux)', '', ''],
      markOnlineOnConnect: true, // set false for offline
      generateHighQualityLinkPreview: false, // make high preview link
      getMessage: async (key) => {
         let jid = jidNormalizedUser(key.remoteJid)
         let msg = await store.loadMessage(jid, key.id)

         return msg?.message || ""
      },
      msgRetryCounterCache, // Resolve waiting messages
      defaultQueryTimeoutMs: undefined, // for this issues https://github.com/WhiskeySockets/Baileys/issues/276
   })

   store.bind(hisoka.ev)

   // push update name to store.contacts
   hisoka.ev.on("contacts.update", (update) => {
      for (let contact of update) {
         let id = jidNormalizedUser(contact.id)
         if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
      }
   })

   // bind extra client
   await Client({ hisoka, store })

	if (pairingCode && !hisoka.authState.creds.registered) {
		let phoneNumber = await question("Please type your WhatsApp number: ");
		phoneNumber = phoneNumber.replace(/[^0-9]/g, "")
	
		if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) {
			console.log("Invalid number")
			phoneNumber = await question("Please type your WhatsApp number: ");
			phoneNumber = phoneNumber.replace(/[^0-9]/g, "")
		}
	
		let code = await hisoka.requestPairingCode(phoneNumber)
		code = code?.match(/.{1,4}/g)?.join("-") || code
		console.log("Number: "+phoneNumber+"\nPairing Code: "+code+"\n")
		rl.close()
	}

   // for auto restart when error client
   hisoka.ev.on("connection.update", async (update) => {
      const { lastDisconnect, connection, qr } = update
      if (connection) {
         console.info(`Connection Status : ${connection}`)
      }

      if (connection === "close") {
         let reason = new Boom(lastDisconnect?.error)?.output.statusCode
         if (reason === DisconnectReason.badSession) {
            console.log(`Bad Session File, Please Delete Session and Scan Again`)
            process.send('reset')
         } else if (reason === DisconnectReason.connectionClosed) {
            console.log("Connection closed, reconnecting....")
            await start()
         } else if (reason === DisconnectReason.connectionLost) {
            console.log("Connection Lost from Server, reconnecting...")
            await start()
         } else if (reason === DisconnectReason.connectionReplaced) {
            console.log("Connection Replaced, Another New Session Opened, Please Close Current Session First")
            process.exit(1)
         } else if (reason === DisconnectReason.loggedOut) {
            console.log(`Device Logged Out, Please Scan Again And Run.`)
            process.exit(1)
         } else if (reason === DisconnectReason.restartRequired) {
            console.log("Restart Required, Restarting...")
            await start()
         } else if (reason === DisconnectReason.timedOut) {
            console.log("Connection TimedOut, Reconnecting...")
            process.send('reset')
         } else if (reason === DisconnectReason.multideviceMismatch) {
            console.log("Multi device mismatch, please scan again")
            platform() === "win32" ? process.kill(process.pid, "SIGINT") : process.kill()
         } else {
            console.log(reason)
            process.send('reset')
         }
      }

      if (connection === "open") {
         hisoka.sendMessage(config.options.owner[0] + "@s.whatsapp.net", {
            text: `${hisoka?.user?.name || "Bot"} has Connected...`,
         })
      }
   })

   // write session
   hisoka.ev.on("creds.update", saveCreds)

   // messages
   hisoka.ev.on("messages.upsert", async (message) => {
      if (!message.messages) return
      const m = await Serialize(hisoka, message.messages[0])
      await (await import(`./event/message.js?v=${Date.now()}`)).default(hisoka, m, message)
   })

   // group participants update
   hisoka.ev.on("group-participants.update", async (message) => {
      await (await import(`./event/group-participants.js?v=${Date.now()}`)).default(hisoka, message)
   })

	hisoka.ev.on("messages.delete", async (json) => {
		console.log(json)
		
		// const { Serialize } = (await import("../lib/serialize.js"))
		
		/*
		m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
		let theDelete = hisoks.chats.get(m.key.remoteJid)
		let theDeleted = theDelete.messages.dict[`${m.key.id}|${m.key.fromMe ? 1 : 0}`]
		let delContent = hisoka.generateForwardMessageContent(theDeleted, false)
		let delType = Object.keys(delContent)[0]
		deltext = `Deleted Message (${delType})\n${m.key.remoteJid}\n\n${m.participant.split("@")[0]}, @${m.participant.split("@")[0]}\n› Date: 00 00 00`
		hisoka.sendMessage(m.key.remoteJid, { text: deltext, contextInfo: { mentionedJid: [m.participant] }}, { quoted: m.message })
		*/
	})

   // auto reject call when user call
   hisoka.ev.on("call", async (json) => {
      if (config.options.antiCall) {
         for (const id of json) {
            if (id.status === "offer") {
               await hisoka.rejectCall(id.id, id.from)
            }
         }
      }
   })

	// rewrite database every 30 seconds
	setInterval(async () => {
		if (global.db) await database.write(global.db)
		console.log(new Date().toLocaleTimeString('id-ID', {
			hour12: false,
			hour: '2-digit',
			minute: '2-digit',
			timeZone: 'Asia/Jakarta'
		}).replace(".", ":")+" - Database saved!")
	}, 30000) // write database every 30 seconds

   return hisoka
}

start()